import { DeleteUserComponent } from './delete-user/delete-user.component';

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListsUsersComponent } from './lists-users/lists-users.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { AddUserComponent } from './add-user/add-user.component';
import { EditUserComponent } from './edit-user/edit-user.component';

import {FormsModule,ReactiveFormsModule} from '@angular/forms'
import { MatTableModule } from '@angular/material/table' 
import {MatButtonModule} from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import {MatIconModule} from '@angular/material/icon';
@NgModule({
  declarations: [
    ListsUsersComponent,
    ViewUserComponent,
    AddUserComponent,
    EditUserComponent,
    DeleteUserComponent
    
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatTableModule,
    MatButtonModule,
    MatDialogModule,
    MatIconModule
  
  ],
  entryComponents:[
    EditUserComponent,
    
  ],
  providers:[EditUserComponent]
})
export class UsersModule { }

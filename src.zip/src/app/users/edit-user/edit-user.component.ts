import Swal from 'sweetalert2';
import { Component, ComponentFactoryResolver, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';


@Component({
  selector: 'app-edit-user',
  templateUrl:'./edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  rowData:any;

  UserForm:FormGroup =new FormGroup({
    UserId: new FormControl('',Validators.required),
    Username: new FormControl('',Validators.required),
    Lastname: new FormControl('',Validators.required),
    email: new FormControl('',Validators.required),
  })
  IsmodelShow: boolean | undefined;

  constructor(public dialogRef: MatDialogRef<EditUserComponent>,
    @Inject(MAT_DIALOG_DATA) public data:any) { 
     this.rowData=data;
     console.log(this.rowData,"-->>");

     this.UserForm.patchValue({
       UserId:this.rowData.id,
       Username:this.rowData.first_name,
       Lastname:this.rowData.last_name,
       email:this.rowData.email
      })
    }
   
  
  /**
   * Update User 
   */
    updateUser(){
     console.log(this.UserForm.value,"Update data")

     Swal.fire({
      title: 'Record Updated Successfully!',timer:3000
      
    })
 
    }
  ngOnInit(): void {
  }

  close() {
    this.IsmodelShow=true;// set false while you need open your model popup
   // do your more code
 }
 }

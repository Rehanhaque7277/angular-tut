import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl, Validators} from '@angular/forms'
@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  UserForm:FormGroup =new FormGroup({
    UserId: new FormControl('',Validators.required),
    Username: new FormControl('',Validators.required),
    Lastname: new FormControl('',Validators.required),
    email: new FormControl('',Validators.required),
  })

  constructor() { }

  ngOnInit(): void {
  }

  addUser(){

    console.log(this.UserForm.value)


  }
  
}

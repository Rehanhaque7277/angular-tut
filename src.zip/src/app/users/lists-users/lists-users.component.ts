import { EditUserComponent } from './../edit-user/edit-user.component';
import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { UserService } from 'src/app/services/user.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import Swal from 'sweetalert2';



@Component({
  selector: 'app-lists-users',
  templateUrl: './lists-users.component.html',
  styleUrls: ['./lists-users.component.css']
})
export class ListsUsersComponent implements OnInit {
  userList: any;
  dataSource = new MatTableDataSource()

  displayedColumns=["id","first_name","last_name","action"];
  constructor(private _userService:UserService,public dialog: MatDialog) { 

    
  }
  

  ngOnInit(): void {
    this._userService.listUser().subscribe((res: any) =>{
      // console.log(data,"nik++")
      this.userList=res.employees;
// console.log(this.userList);
this.dataSource = new MatTableDataSource(this.userList);
      
      // this.listUsers=data
    });
  }

  deleteUser(data:any){
    Swal.fire({
      title: 'Are you sure want to delete?',
      text: 'You will not be able to recover this user details!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {

        Swal.fire(
          'Deleted!',
          'success'
        )
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'error'
        )
      }
    })
  }
  

  openDialog(data:any): void {
    const dialogRef = this.dialog.open(EditUserComponent, {
      width: '400px',
      // height:'500px',
      data: data,
    });

    dialogRef.afterClosed().subscribe(result => {

    this.ngOnInit();
    
      // console.log('The dialog was closed');
      // this.animal = result;
    });
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UserService {
 
 baseUrl:string = 'https://run.mocky.io/v3/7d6c784d-4cbc-4ab7-a09e-14671686962b';

  constructor(private http:HttpClient) {

   }

  public listUser(): Observable<any> { 
    return this.http.get(this.baseUrl);
  }
}

export class userService { }









